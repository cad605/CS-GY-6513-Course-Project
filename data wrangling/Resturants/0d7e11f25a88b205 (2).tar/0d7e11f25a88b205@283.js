import define1 from "./606721ba06ae51d6@549.js";
import define2 from "./a33468b95d0b15b0@703.js";

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], function(md){return(
md`# Visualization`
)});
  main.variable(observer("d3")).define("d3", ["require"], function(require){return(
require('d3@6')
)});
  main.variable(observer("url")).define("url", function(){return(
"https://raw.githubusercontent.com/benji7890/csv/main/U.S%20Restaurants.csv?token=AEC6CFKXICLVQIJ67D7BOITATM5RQ"
)});
  main.variable(observer("data")).define("data", ["d3","url"], function(d3,url){return(
d3.csv(url, a => ({
    // combine the date and time strings into one Date object
    date: d3.timeParse('%m/%d/%Y %H:%M')(a.date),
    state: a.State_Tribe_Territory,
    restriction: a.order_group
}))
)});
  main.variable(observer("linedata")).define("linedata", ["d3","data"], function(d3,data){return(
d3.rollup(
  data,
  count => count.length,
  d => d.restriction,
  d => (d.date))
)});
  main.variable(observer()).define(["usaGeo"], function(usaGeo){return(
usaGeo
)});
  main.variable(observer("states")).define("states", ["usaGeo"], function(usaGeo){return(
usaGeo.features.filter(d => d.properties.NAME !== 'Puerto Rico')
)});
  main.variable(observer("stateToAbbr")).define("stateToAbbr", function(){return(
{
    "AL": "Alabama",
    "AK": "Alaska",
    "AS": "American Samoa",
    "AZ": "Arizona",
    "AR": "Arkansas",
    "CA": "California",
    "CO": "Colorado",
    "CT": "Connecticut",
    "DE": "Delaware",
    "DC": "District Of Columbia",
    "FM": "Federated States Of Micronesia",
    "FL": "Florida",
    "GA": "Georgia",
    "GU": "Guam",
    "HI": "Hawaii",
    "ID": "Idaho",
    "IL": "Illinois",
    "IN": "Indiana",
    "IA": "Iowa",
    "KS": "Kansas",
    "KY": "Kentucky",
    "LA": "Louisiana",
    "ME": "Maine",
    "MH": "Marshall Islands",
    "MD": "Maryland",
    "MA": "Massachusetts",
    "MI": "Michigan",
    "MN": "Minnesota",
    "MS": "Mississippi",
    "MO": "Missouri",
    "MT": "Montana",
    "NE": "Nebraska",
    "NV": "Nevada",
    "NH": "New Hampshire",
    "NJ": "New Jersey",
    "NM": "New Mexico",
    "NY": "New York",
    "NC": "North Carolina",
    "ND": "North Dakota",
    "MP": "Northern Mariana Islands",
    "OH": "Ohio",
    "OK": "Oklahoma",
    "OR": "Oregon",
    "PW": "Palau",
    "PA": "Pennsylvania",
    "PR": "Puerto Rico",
    "RI": "Rhode Island",
    "SC": "South Carolina",
    "SD": "South Dakota",
    "TN": "Tennessee",
    "TX": "Texas",
    "UT": "Utah",
    "VT": "Vermont",
    "VI": "Virgin Islands",
    "VA": "Virginia",
    "WA": "Washington",
    "WV": "West Virginia",
    "WI": "Wisconsin",
    "WY": "Wyoming"
}
)});
  main.variable(observer("data1")).define("data1", ["d3","data"], function(d3,data){return(
d3.rollup(
  data,
  count => count.length,
  d => d.state,
  d => d.restriction)
)});
  main.variable(observer("abbr")).define("abbr", ["data1","stateToAbbr"], function(data1,stateToAbbr){return(
Array.from(data1).map(d => {
  return {state: stateToAbbr[d[0]], data: Array.from(d[1], ([restriction, count]) => ({restriction, count}))
}})
)});
  main.variable(observer("stateToCount")).define("stateToCount", ["abbr"], function(abbr){return(
abbr.filter(d => d.state !== 'Puerto Rico' && d.state !== 'Guam' && d.state !== 'American Samoa' && d.state !== 'Northern Mariana Islands' && d.state !== 'Virgin Islands')
)});
  main.variable(observer("dataset")).define("dataset", ["stateToCount","restrictions"], function(stateToCount,restrictions){return(
Object.fromEntries(stateToCount
  .map(d => {
    const key = d.state;
    let values = [];
  let seen = false;
       restrictions.forEach((restriction) => {
         seen = false;
   d.data.forEach((data) => {
      if(data.restriction == restriction && seen == false) {
        values.push(data);
        seen = true;
      }})
       if (seen == false) {
          values.push({restriction: restriction, count:0});
        seen = true;
        }});
    return [key, values];
  }))
)});
  main.variable(observer("restrictions")).define("restrictions", ["d3","data"], function(d3,data){return(
Array.from(d3.rollup(
  data,
  count => count.length,
  d => d.restriction)).map(a => a[0])
)});
  main.variable(observer("maxCount")).define("maxCount", function(){return(
50000
)});
  const child1 = runtime.module(define1);
  main.import("usaGeo", child1);
  const child2 = runtime.module(define2);
  main.import("swatches", child2);
  main.variable(observer("color")).define("color", ["d3","restrictions"], function(d3,restrictions){return(
d3.scaleOrdinal()
  .domain(restrictions)
  .range(d3.schemeCategory10)
)});
  main.variable(observer("pie")).define("pie", ["d3"], function(d3){return(
d3.pie()
  .value(d => d.count)
)});
  main.variable(observer("radius")).define("radius", ["d3","maxCount"], function(d3,maxCount){return(
d3.scaleSqrt()
    .domain([0, maxCount])
    .range([0, 30])
)});
  main.variable(observer("arc")).define("arc", ["d3"], function(d3){return(
d3.arc()
  .innerRadius(0)
  .outerRadius(d => 15)
)});
  main.variable(observer()).define(["swatches","color"], function(swatches,color){return(
swatches({ color: color})
)});
  main.variable(observer()).define(["width","d3","DOM","usaGeo","states","dataset","pie","arc","color"], function(width,d3,DOM,usaGeo,states,dataset,pie,arc,color)
{
  const margin = ({top: 0, right: 0, bottom: 0, left: 0})
  const visWidth = width - margin.top - margin.bottom
  const visHeight = (width * 0.625) - margin.left - margin.right
  const svg = d3.select(DOM.svg(visWidth + margin.left + margin.right,
                                visHeight + margin.top + margin.bottom));
  const projection =  d3.geoAlbersUsa()
  .fitSize([visWidth, visHeight], usaGeo)
  
  const path = d3.geoPath().projection(projection)
  
  const g = svg.append('g')
      .attr('transform', `translate(${margin.left}, ${margin.top})`);

  g.selectAll('path')
    .data(states)
    .join('path')
      .attr('d', path)
      .attr('fill', '#d3d3d3')
      .attr('stroke', 'white');
  
  const groups = g.selectAll('g')
    .data(states)
    .join('g')
      .attr('transform', state => `translate(${path.centroid(state)})`);
  
  groups.selectAll('path')
    .data(s => dataset[s.properties.NAME] ? pie(dataset[s.properties.NAME]):[])
    .join('path')
      .attr('d', arc)
      .attr('fill', slice => color(slice.data.restriction))

  return svg.node();
}
);
  main.variable(observer()).define(["md"], function(md){return(
md`# Line Visualization`
)});
  main.variable(observer("color1")).define("color1", ["d3","restrictions"], function(d3,restrictions){return(
d3.scaleOrdinal()
  .domain(restrictions)
  .range(d3.schemeCategory10)
)});
  main.variable(observer("linedata1")).define("linedata1", ["linedata","d3"], function(linedata,d3){return(
Array.from(linedata, ([restriction, data]) => ({
  restriction: restriction,
  data: Array.from(data, ([date, count]) => ({date, count}))
  .sort((a, b) => d3.ascending(a.date, b.date))
}))
)});
  main.variable(observer("months")).define("months", function(){return(
['Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
)});
  main.variable(observer()).define(["swatches","color1"], function(swatches,color1){return(
swatches ({color: color1})
)});
  main.variable(observer()).define(["width","d3","data","linedata1","color1"], function(width,d3,data,linedata1,color1)
{
  const margin = {top: 40, right: 0, bottom: 30, left: 40};

  const visWidth = width - margin.left - margin.right;
  const visHeight = 600 - margin.top - margin.bottom;

  const svg = d3.create('svg')
      .attr('width', visWidth + margin.left + margin.right)
      .attr('height', visHeight + margin.top + margin.bottom);

  const g = svg.append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

  // add title

  g.append("text")
    .attr("x", visWidth / 2)
    .attr("y", -margin.top)
    .attr("text-anchor", "middle")
    .attr("dominant-baseline", "hanging")
    .attr("font-family", "sans-serif")
    .attr("font-size", "16px")
    .text("Number & Type of Restaurant Restrictions in 2020");
  
  // create scales
  
  const x = d3.scaleTime()
      .domain(d3.extent(data, d=> d.date))
      .range([0, visWidth]);
  
  const y = d3.scaleLinear()
      .domain([0, 5000]).nice()
      .range([visHeight, 0]);
  
  // create and add axes
  
  const xAxis = d3.axisBottom(x);   
  
  g.append('g')
    .attr('transform', `translate(0,${visHeight})`)
    .call(xAxis);
  
  const yAxis = d3.axisLeft(y)

  g.append("g")
      .call(yAxis)
      .call(g => g.selectAll(".domain").remove());
  
  // draw line
  
  const line = d3.line()
      .x(d => x(d.date))
      .y(d => y(d.count));
  
  const series = g.append("g")
    .selectAll('g')
    .data(linedata1)
    .join('g')
      .attr('stroke', d => color1(d.restriction))
    .append('path')
     .datum(d => d.data)
     .attr("d", line)
     .attr("fill", "none")
     .attr('stroke-width', 2)
     .attr('d', line);
  
  return svg.node();
}
);
  main.variable(observer("url1")).define("url1", function(){return(
"https://gist.githubusercontent.com/benji7890/7c747d0e384371cc9204e6e05df3114d/raw/2d9c13e6f2efda9366e7463f32aa46e2482ff7f4/opentable.csv"
)});
  main.variable(observer("ot_data")).define("ot_data", ["d3","url1"], function(d3,url1){return(
d3.csv(url1, a => ({
    // combine the date and time strings into one Date object
    date: d3.timeParse('%m/%d/%Y')(a.Date),
    change: a.Change * 100                   
}))
)});
  main.variable(observer()).define(["width","d3","ot_data"], function(width,d3,ot_data)
{
  const margin = {top: 40, right: 20, bottom: 20, left: 40};

  const visWidth = width - margin.left - margin.right;
  const visHeight = 600 - margin.top - margin.bottom;

  const svg = d3.create('svg')
      .attr('width', visWidth + margin.left + margin.right)
      .attr('height', visHeight + margin.top + margin.bottom);

  const g = svg.append("g")
      .attr("transform", `translate(${margin.left}, ${margin.top})`);

  // add title

  g.append("text")
    .attr("x", visWidth / 2)
    .attr("y", -margin.top)
    .attr("text-anchor", "middle")
    .attr("dominant-baseline", "hanging")
    .attr("font-family", "sans-serif")
    .attr("font-size", "16px")
    .text("Percent change of Seated Diners in Restaurants in 2020/2021 compared to 2019");
  
  // create scales
  
  const x = d3.scaleTime()
      .domain(d3.extent(ot_data, d => d.date))
      .range([0, visWidth]);
  
  const y = d3.scaleLinear()
      .domain([-100, 6]).nice()
      .range([visHeight, 0]);
  
  // create and add axes
  
  const xAxis = d3.axisBottom(x);
      // .ticks(d3.timeHour.every(2));
  
  g.append("g")
      .attr("transform", `translate(0, ${visHeight})`)
      .call(xAxis);
  
  const yAxis = d3.axisLeft(y);

  g.append("g")
      .call(yAxis)
      .call(g => g.selectAll(".domain").remove());
  
  // draw line
  
  const line = d3.line()
      .x(d => x(d.date))
      .y(d => y(d.change));
  
  g.append("path")
     .datum(ot_data)
     .attr("d", line)
     .attr("fill", "none")
     .attr("stroke", "steelblue")
     .attr("stroke-width", 2);
  
  return svg.node();
}
);
  return main;
}
