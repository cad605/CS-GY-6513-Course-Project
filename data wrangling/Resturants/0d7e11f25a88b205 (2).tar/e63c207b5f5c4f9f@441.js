// https://observablehq.com/@nyuvis/small-multiples-practice-solutions@441
import define1 from "./a33468b95d0b15b0@703.js";
import define2 from "./606721ba06ae51d6@549.js";

export default function define(runtime, observer) {
  const main = runtime.module();
  const fileAttachments = new Map([["cbs-grid-cartogram.png",new URL("./files/40cb8af1b197e694a192a215127889d0b2aef0e23b2a74d3f57c41f3f5bf8cf23246f220644490676dbe5cb2f8c0c12c8eff4a51eb13caf0795dfc9f8511eac7",import.meta.url)],["nyt-grid-cartogram.png",new URL("./files/6c247654e2ab06ff88263b0f241ab72e49fe33407f891260bfc4f35c530c7edb639374200de23e0deec8bfa379faa7246fccbc3c267e5358879c08128fde1cc9",import.meta.url)]]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md","FileAttachment"], async function(md,FileAttachment){return(
md`# Small Multiples Practice - Solutions

Below are two examples of grid cartograms from New York Times and CBS for the 2020 presedential election.

<figure>
  ${await FileAttachment("nyt-grid-cartogram.png").image()}
  <figcaption>[New York Times](https://www.nytimes.com/interactive/2020/11/03/us/elections/forecast-uncounted-votes-president.html?action=click&pgtype=Article&state=default&module=styln-elections-2020&region=TOP_BANNER&context=election_recirc)</figcaption>
</figure>

<figure>
  ${await FileAttachment("cbs-grid-cartogram.png").image()}
  <figcaption>[CBS](https://www.cbsnews.com/election/2020/president/)</figcaption>
</figure>

You can see more examples in this [notebook](/@severo/grid-cartograms), this [notebook](/@sambhavjain/covid-in-the-us-two-week-snapshot), and in this [Washington Post article](https://www.washingtonpost.com/wp-srv/special/business/states-most-threatened-by-trade/).

Let's see how we can make a grid cartogram for state unemployment data. We will represent each state with a square and color it according to its unemployment rate.`
)});
  main.variable(observer()).define(["unemployment"], function(unemployment){return(
unemployment
)});
  main.variable(observer()).define(["stateToAbbr"], function(stateToAbbr){return(
stateToAbbr
)});
  main.variable(observer()).define(["md"], function(md){return(
md`We can use a tool like [aRanger](http://code.minnpost.com/aranger/) to generate the data for the grid of states or we can get a premade arrangement from this [block by Jane Pong](https://bl.ocks.org/officeofjane/2c3ed88c4be050d92765de912d71b7c4). This gives us the coordinates of each state in the grid. Each sub-array gives the column, row, and abbreviation for the state.`
)});
  main.variable(observer("stateGrid")).define("stateGrid", function(){return(
[[0,0,"AK"],[10,0,"ME"],[5,1,"WI"],[9,1,"VT"],[10,1,"NH"],[0,2,"WA"],[1,2,"ID"],[2,2,"MT"],[3,2,"ND"],[4,2,"MN"],[5,2,"IL"],[6,2,"MI"],[7,2,"NY"],[9,2,"MA"],[0,3,"OR"],[1,3,"NV"],[2,3,"WY"],[3,3,"SD"],[4,3,"IA"],[5,3,"IN"],[6,3,"OH"],[7,3,"PA"],[8,3,"NJ"],[9,3,"CT"],[10,3,"RI"],[0,4,"CA"],[1,4,"UT"],[2,4,"CO"],[3,4,"NE"],[4,4,"MO"],[5,4,"KY"],[6,4,"WV"],[7,4,"VA"],[8,4,"MD"],[9,4,"DE"],[1,5,"AZ"],[2,5,"NM"],[3,5,"KS"],[4,5,"AR"],[5,5,"TN"],[6,5,"NC"],[7,5,"SC"],[8,5,"DC"],[3,6,"OK"],[4,6,"LA"],[5,6,"MS"],[6,6,"AL"],[7,6,"GA"],[0,7,"HI"],[3,7,"TX"],[8,7,"FL"]]
)});
  main.variable(observer()).define(["md"], function(md){return(
md`Next, will create an object that maps from a state's abbreviation to its row and column. For example, \`stateToPosition["ME"]\` should equal \`{ row: 0, col: 10 }\`.`
)});
  main.variable(observer("stateToPosition")).define("stateToPosition", ["stateGrid"], function(stateGrid){return(
Object.fromEntries(stateGrid.map(([col, row, state]) => [state, {row, col}]))
)});
  main.variable(observer()).define(["md"], function(md){return(
md`We can use \`stateToPosition\` to set the row and column for each object in \`unemployment\`.`
)});
  main.variable(observer("unemploymentWithPosition")).define("unemploymentWithPosition", ["unemployment","stateToAbbr","stateToPosition"], function(unemployment,stateToAbbr,stateToPosition){return(
unemployment.map(d => {
  const abbr = stateToAbbr[d.state];
  const {row, col} = stateToPosition[abbr];
  
  return {
    state: abbr,
    rate: d.rate,
    row: row,
    col: col,
  }
})
)});
  main.variable(observer()).define(["md"], function(md){return(
md`Next, we will create the scales. To start, we will get the number of rows and columns in the grid.`
)});
  main.variable(observer("numberOfRows")).define("numberOfRows", ["d3","unemploymentWithPosition"], function(d3,unemploymentWithPosition){return(
d3.max(unemploymentWithPosition, d => d.row) + 1
)});
  main.variable(observer("numberOfCols")).define("numberOfCols", ["d3","unemploymentWithPosition"], function(d3,unemploymentWithPosition){return(
d3.max(unemploymentWithPosition, d => d.col) + 1
)});
  main.variable(observer()).define(["md"], function(md){return(
md`Then we will set the size of a cell in the grid and calculate the size of the map simply by multiplying the cell size by the number of rows to get the height and by the number of columns to get the width.`
)});
  main.variable(observer("cellSize")).define("cellSize", function(){return(
50
)});
  main.variable(observer("mapWidth")).define("mapWidth", ["numberOfCols","cellSize"], function(numberOfCols,cellSize){return(
numberOfCols * cellSize
)});
  main.variable(observer("mapHeight")).define("mapHeight", ["numberOfRows","cellSize"], function(numberOfRows,cellSize){return(
numberOfRows * cellSize
)});
  main.variable(observer()).define(["md"], function(md){return(
md`Now we can define the scales that we wil use to position the cells.`
)});
  main.variable(observer("row")).define("row", ["d3","numberOfRows","mapHeight"], function(d3,numberOfRows,mapHeight){return(
d3.scaleBand()
    .domain(d3.range(numberOfRows))
    .range([0, mapHeight])
    .padding(0.05)
)});
  main.variable(observer("col")).define("col", ["d3","numberOfCols","mapWidth"], function(d3,numberOfCols,mapWidth){return(
d3.scaleBand()
    .domain(d3.range(numberOfCols))
    .range([0, mapWidth])
    .padding(0.05)
)});
  main.variable(observer()).define(["md"], function(md){return(
md`We will also define a color scale.`
)});
  main.variable(observer("color")).define("color", ["d3","unemployment"], function(d3,unemployment){return(
d3.scaleSequential()
    .domain(d3.extent(unemployment, d => d.rate))
    .interpolator(d3.interpolateBlues)
)});
  main.variable(observer()).define(["legend","color"], function(legend,color){return(
legend({
  color: color,
  title: 'Unemployment Rate, Decemeber 2019'
})
)});
  main.variable(observer("gridCartogram")).define("gridCartogram", ["d3","mapWidth","mapHeight","unemploymentWithPosition","col","row","color"], function(d3,mapWidth,mapHeight,unemploymentWithPosition,col,row,color)
{
  // set up
  
  const svg = d3.create('svg')
      .attr('width', mapWidth)
      .attr('height', mapHeight);
  
  // add a group for each cell and position it according to its row and column
  
  const cells = svg.selectAll('g')
    .data(unemploymentWithPosition)
    .join('g')
      .attr('transform', d => `translate(${col(d.col)}, ${row(d.row)})`);
  
  // add a rectangle to each group and make it take up the entire cell
  
  cells.append('rect')
      .attr('width', col.bandwidth())
      .attr('height', row.bandwidth())
      .attr('fill', d => color(d.rate));
  
  // add state label to each group
  
  cells.append('text')
      .attr('font-size', 12)
      .attr('font-family', 'sans-serif')
      .attr('dominant-baseline', 'middle')
      .attr('text-anchor', 'middle')
      .attr('x', col.bandwidth() / 2)
      .attr('y', row.bandwidth() / 2)
      .text(d => d.state);
  
  return svg.node();
}
);
  main.variable(observer()).define(["md"], function(md){return(
md`---

## Appendix`
)});
  main.variable(observer("d3")).define("d3", ["require"], function(require){return(
require('d3@6')
)});
  const child1 = runtime.module(define1);
  main.import("legend", child1);
  const child2 = runtime.module(define2);
  main.import("unemployment", child2);
  main.import("stateToAbbr", child2);
  return main;
}
